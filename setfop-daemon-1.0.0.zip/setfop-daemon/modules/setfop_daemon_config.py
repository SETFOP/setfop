# /opt/setfop-daemon/modules/setfop_daemon_config.py

"""
Configuration module for setfop-daemon.

Provides configuration values for daemon runtime behavior.
"""

import os

class Config:
    """
    Configuration loader for setfop-daemon.
    """

    def __init__(self):
        # Read daemon version
        version_file = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "VERSION"
        )

        try:
            with open(version_file, "r") as f:
                self.version = f.read().strip()
        except Exception:
            self.version = "unknown"

        # Default paths
        self.config_file = "/etc/setfop/setfop-daemon.config"
        self.log_file = "/var/log/setfop/drift.log"
        self.baseline_file = "/var/lib/setfop/baseline.setfop"

        # Default behavior
        self.log_level = "INFO"

        self.watch_paths = [
            "/etc",
            "/opt",
            "/var/www"
        ]

        # Load config overrides
        self._load_config()

    def _load_config(self):
        """
        Load configuration overrides from file.
        """
        if not os.path.exists(self.config_file):
            return

        try:
            with open(self.config_file) as f:
                for line in f:
                    line = line.strip()

                    if not line or line.startswith("#"):
                        continue

                    if "=" not in line:
                        continue

                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()

                    if key == "log_level":
                        self.log_level = value
                    elif key == "baseline_file":
                        self.baseline_file = value
                    elif key == "log_file":
                        self.log_file = value
                    elif key == "watch_paths":
                        self.watch_paths = [
                            p.strip()
                            for p in value.split(",")
                            if p.strip()
                        ]
        except Exception:
            pass