# /opt/setfop-daemon/modules/setfop_daemon_utils.py

"""
Utility functions used across setfop-daemon modules.
"""

import os
import subprocess
import uuid

def generate_event_id():
    """
    Generate short unique ID for drift events.
    """
    return str(uuid.uuid4())[:8]

def get_file_attributes(path):
    """
    Collect filesystem attributes used for drift detection.
    """
    try:
        stat = os.stat(path)

        attributes = {
            "mode": oct(stat.st_mode)[-3:],
            "uid": stat.st_uid,
            "gid": stat.st_gid,
            "size": stat.st_size,
            "xattrs": {}
        }

        try:
            output = subprocess.check_output(
                ["getfattr", "-d", path],
                stderr=subprocess.DEVNULL
            )

            for line in output.decode().splitlines():
                if "=" not in line:
                    continue

                key, value = line.split("=", 1)
                attributes["xattrs"][key.strip()] = value.strip()

        except Exception:
            pass

        return attributes

    except Exception:
        return None

def compare_attributes(old_attrs, new_attrs):
    """
    Compare baseline attributes with current attributes.
    """
    if not old_attrs or not new_attrs:
        return {}

    differences = {}

    for key in old_attrs:
        if key not in new_attrs:
            continue

        if old_attrs[key] != new_attrs[key]:
            differences[key] = (
                old_attrs[key],
                new_attrs[key]
            )

    return differences

def get_max_user_watches():
    """
    Return Linux inotify watch limit.
    """
    try:
        with open("/proc/sys/fs/inotify/max_user_watches") as f:
            return int(f.read().strip())
    except Exception:
        return 8192
