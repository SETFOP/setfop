# /opt/setfop-daemon/modules/setfop_daemon_baseline.py

"""
Baseline management module for setfop-daemon.

Maintains a snapshot of filesystem permissions and metadata
used to detect drift.
"""

import os
import json
import threading
import time

from setfop_daemon_utils import get_file_attributes

class BaselineManager:
    """
    Manages baseline snapshot of filesystem attributes.
    """

    def __init__(self, baseline_file):
        self.baseline_file = baseline_file
        self.baseline = {}
        self.lock = threading.Lock()
        self.last_persist_time = 0
        self.persist_interval = 30
        os.makedirs(os.path.dirname(self.baseline_file), exist_ok=True)

    def load_baseline(self):
        """
        Load baseline snapshot from disk.
        """
        with self.lock:
            if not os.path.exists(self.baseline_file):
                self.baseline = {}
                return

            try:
                with open(self.baseline_file, "r") as f:
                    self.baseline = json.load(f)
            except Exception:
                self.baseline = {}

    def persist_baseline(self):
        """
        Persist baseline snapshot to disk.
        """
        with self.lock:
            try:
                with open(self.baseline_file, "w") as f:
                    json.dump(self.baseline, f, indent=2)
                self.last_persist_time = time.time()
            except Exception:
                pass

    def create_baseline(self, paths):
        """
        Build initial baseline snapshot.
        """
        with self.lock:
            self.baseline = {}
            for path in paths:
                self._add_path_recursive(path)
            self.persist_baseline()

    def update_path(self, path):
        """
        Update baseline entry for a path.
        """
        with self.lock:
            attributes = get_file_attributes(path)
            if attributes:
                self.baseline[path] = attributes
            else:
                if path in self.baseline:
                    del self.baseline[path]

            if time.time() - self.last_persist_time > self.persist_interval:
                self.persist_baseline()

    def _add_path_recursive(self, path):
        """
        Add path and contents to baseline.
        """
        if not os.path.exists(path):
            return

        attributes = get_file_attributes(path)
        if attributes:
            self.baseline[path] = attributes

        if os.path.isdir(path):
            try:
                for root, dirs, files in os.walk(path):
                    for d in dirs:
                        dir_path = os.path.join(root, d)
                        attrs = get_file_attributes(dir_path)
                        if attrs:
                            self.baseline[dir_path] = attrs

                    for f in files:
                        file_path = os.path.join(root, f)
                        attrs = get_file_attributes(file_path)
                        if attrs:
                            self.baseline[file_path] = attrs
            except Exception:
                pass

    def get_baseline(self):
        """
        Return copy of baseline snapshot.
        """
        with self.lock:
            return dict(self.baseline)

    def get_directories(self):
        """
        Return list of directories currently in baseline.
        """
        directories = []
        with self.lock:
            for path in self.baseline.keys():
                if os.path.isdir(path):
                    directories.append(path)
        return directories
