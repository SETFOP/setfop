# /opt/setfop-daemon/modules/setfop_daemon_drift_detector.py

"""
Drift detection module for setfop-daemon.
Detects permission drift by comparing current file attributes with baseline.
"""

import os
import threading
import time

from setfop_daemon_utils import (
    get_file_attributes,
    compare_attributes,
    generate_event_id
)

from setfop_daemon_logger import Logger

class DriftDetector:
    """
    Detects permission drift in filesystem objects.
    """

    def __init__(self, baseline_manager, audit_worker):
        self.baseline_manager = baseline_manager
        self.audit_worker = audit_worker

        # store events awaiting attribution
        self.pending_events = {}
        self.lock = threading.Lock()

    def process_event(self, path, event_types):
        """
        Process an inotify filesystem event.
        """
        # Ignore paths that disappeared between event and inspection
        if not os.path.exists(path):
            return

        current_attrs = get_file_attributes(path)
        if not current_attrs:
            return

        baseline = self.baseline_manager.get_baseline()
        baseline_attrs = baseline.get(path)

        # If the file is new, add it to baseline
        if not baseline_attrs:
            self.baseline_manager.update_path(path)
            return

        differences = compare_attributes(baseline_attrs, current_attrs)
        if not differences:
            return

        event_id = generate_event_id()
        change_parts = []

        for attr, (old_val, new_val) in differences.items():
            change_parts.append(f"{attr}: {old_val} → {new_val}")

        change_description = ", ".join(change_parts)

        # Log drift immediately (unknown actor for now)
        Logger.log_drift(
            "unknown",
            "unknown",
            path,
            change_description
        )

        # Store event so attribution can update it later
        with self.lock:
            self.pending_events[event_id] = {
                "path": path,
                "change": change_description,
                "timestamp": time.time()
            }

        # Update baseline so the same change is not logged repeatedly
        self.baseline_manager.update_path(path)

        # Ask audit worker to resolve actor asynchronously
        self.audit_worker.submit_task(event_id, path)

    def resolve_attribution(self, event_id, user, process):
        """
        Called by the audit worker when attribution is found.
        """
        with self.lock:
            if event_id not in self.pending_events:
                return

            event = self.pending_events[event_id]

            Logger.log_attribution_update(
                user,
                process,
                event["path"]
            )

            del self.pending_events[event_id]
