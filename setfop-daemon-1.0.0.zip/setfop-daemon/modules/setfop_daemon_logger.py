# /opt/setfop-daemon/modules/setfop_daemon_logger.py

"""
Logging module for setfop-daemon.

Responsible for writing structured drift events to disk.
"""

import logging
import os
import threading

class Logger:
    """
    Thread-safe logger used across daemon modules.
    """

    _logger = None
    _lock = threading.Lock()

    @classmethod
    def initialize(cls, log_file, log_level="INFO"):
        """
        Initialize logger.
        """
        with cls._lock:
            if cls._logger:
                return

            logger = logging.getLogger("setfop-daemon")
            logger.setLevel(getattr(logging, log_level.upper()))

            log_dir = os.path.dirname(log_file)
            os.makedirs(log_dir, exist_ok=True)

            handler = logging.FileHandler(log_file)
            formatter = logging.Formatter(
                "%(asctime)s | %(message)s",
                "%Y-%m-%d %H:%M:%S"
            )

            handler.setFormatter(formatter)
            logger.addHandler(handler)
            cls._logger = logger

    @classmethod
    def _ensure_initialized(cls):
        if not cls._logger:
            cls.initialize("/var/log/setfop/drift.log")

    @classmethod
    def info(cls, message, *args):
        cls._ensure_initialized()
        with cls._lock:
            cls._logger.info(message, *args)

    @classmethod
    def warning(cls, message, *args):
        cls._ensure_initialized()
        with cls._lock:
            cls._logger.warning(message, *args)

    @classmethod
    def error(cls, message, *args):
        cls._ensure_initialized()
        with cls._lock:
            cls._logger.error(message, *args)

    @classmethod
    def debug(cls, message, *args):
        cls._ensure_initialized()
        with cls._lock:
            cls._logger.debug(message, *args)

    @classmethod
    def log_drift(cls, user, process, filepath, change):
        """
        Write drift entry.
        """
        cls._ensure_initialized()
        with cls._lock:
            message = f"{user} -> {process} | {filepath} | {change}"
            cls._logger.info(message)

    @classmethod
    def log_attribution_update(cls, user, process, filepath):
        """
        Append attribution correction.
        """
        cls._ensure_initialized()
        with cls._lock:
            message = f"{user} -> {process} | attribution_update | {filepath}"
            cls._logger.info(message)
