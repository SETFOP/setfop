# /opt/setfop-daemon/modules/setfop_daemon_watcher.py

"""
Filesystem watcher module for setfop-daemon.
Uses inotify to monitor filesystem events.
"""

import os
import threading

import inotify.adapters
import inotify.constants

from setfop_daemon_utils import get_max_user_watches
from setfop_daemon_logger import Logger

class Watcher:
    """
    Filesystem watcher using Linux inotify.
    """

    def __init__(self, paths, drift_detector):
        self.paths = paths
        self.drift_detector = drift_detector

        self.running = False
        self.thread = None
        self.inotify = None

        # Track directories already watched to avoid duplicates
        self.watched_directories = set()

        # Kernel watch limit
        self.max_watches = get_max_user_watches()
        self.warning_threshold = int(self.max_watches * 0.80)

    def start(self):
        """
        Start watcher thread.
        """
        if self.running:
            return

        self.running = True

        self.thread = threading.Thread(
            target=self._watch_loop,
            daemon=True
        )

        self.thread.start()
        Logger.info("Filesystem watcher started")

    def stop(self):
        """
        Stop watcher thread.
        """
        self.running = False

        if self.thread:
            self.thread.join()

        Logger.info("Filesystem watcher stopped")

    def _watch_loop(self):
        """
        Main inotify event loop.
        """
        self.inotify = inotify.adapters.Inotify()
        self._initialize_watches()

        for event in self.inotify.event_gen():
            if not self.running:
                break

            if event is None:
                continue

            self._handle_event(event)

    def _initialize_watches(self):
        """
        Add watches for all directories in baseline.
        """
        directories = self.drift_detector.baseline_manager.get_directories()

        if len(directories) > self.warning_threshold:
            Logger.warning(
                "Watcher count approaching kernel limit (%d/%d)",
                len(directories),
                self.max_watches
            )

        for directory in directories:
            self._add_watch(directory)

    def _add_watch(self, directory):
        """
        Safely add a directory watch.
        """
        if directory in self.watched_directories:
            return

        try:
            self.inotify.add_watch(
                directory,
                inotify.constants.IN_ATTRIB
                | inotify.constants.IN_MODIFY
                | inotify.constants.IN_CREATE
                | inotify.constants.IN_MOVED_FROM
                | inotify.constants.IN_MOVED_TO
                | inotify.constants.IN_DELETE
            )
            self.watched_directories.add(directory)
        except Exception:
            Logger.warning(
                "Failed to add watch for directory: %s",
                directory
            )

def _handle_event(self, event):
        """
        Process a filesystem event.
        """
        header, type_names, watch_path, filename = event

        if not filename:
            return

        # Ensure filename is decoded from bytes if necessary
        if isinstance(filename, bytes):
            filename = filename.decode('utf-8')

        full_path = os.path.join(watch_path, filename)

        # If a new directory appears, start watching it
        if "IN_CREATE" in type_names and os.path.isdir(full_path):
            self._add_watch(full_path)

        try:
            self.drift_detector.process_event(
                full_path,
                type_names
            )
        except Exception as err:
            Logger.error(
                "Error processing event for %s: %s",
                full_path,
                err
            )