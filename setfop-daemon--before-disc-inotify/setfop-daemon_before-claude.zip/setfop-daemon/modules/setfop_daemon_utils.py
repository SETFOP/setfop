# /opt/setfop-daemon/modules/setfop_daemon_utils.py
import os
import stat
import subprocess

def get_file_attributes(path):
    """Gets a dictionary of important file attributes."""
    try:
        stat_info = os.lstat(path)
        attrs = {
            'mode': oct(stat.S_IMODE(stat_info.st_mode))[2:], # e.g., '755'
            'uid': stat_info.st_uid,
            'gid': stat_info.st_gid,
            'size': stat_info.st_size,
            'chattr': get_chattr_flags(path)
        }
        return attrs
    except FileNotFoundError:
        return None
    except Exception as e:
        # Logger might not be initialized here, so just print
        print(f"Error getting attributes for {path}: {e}")
        return None

def get_chattr_flags(path):
    """Gets the chattr flags for a file (e.g., 'e-i')."""
    try:
        # lsattr output looks like: ----e--------- /path/to/file
        result = subprocess.run(['lsattr', path], capture_output=True, text=True, check=True)
        flags = result.stdout.split()[0]
        return flags
    except (subprocess.CalledProcessError, FileNotFoundError):
        # chattr not supported or command not found
        return "----"

def format_attributes_change(old_attrs, new_attrs):
    """Helper function to format a change string."""
    changes = []
    if old_attrs.get('mode') != new_attrs.get('mode'):
        changes.append(f"mode: {old_attrs['mode']} → {new_attrs['mode']}")
    if old_attrs.get('uid') != new_attrs.get('uid') or old_attrs.get('gid') != new_attrs.get('gid'):
        changes.append(f"owner: {old_attrs['uid']}:{old_attrs['gid']} → {new_attrs['uid']}:{new_attrs['gid']}")
    if old_attrs.get('size') != new_attrs.get('size'):
        changes.append(f"size: {old_attrs['size']} → {new_attrs['size']}")
    if old_attrs.get('chattr') != new_attrs.get('chattr'):
        changes.append(f"chattr: {old_attrs['chattr']} → {new_attrs['chattr']}")
    
    return ", ".join(changes)
