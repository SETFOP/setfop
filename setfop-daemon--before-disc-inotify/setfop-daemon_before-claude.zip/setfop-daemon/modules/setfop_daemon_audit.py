# /opt/setfop-daemon/modules/setfop_daemon_audit.py
import subprocess
import re
import threading
import time
from setfop_daemon_logger import Logger

class AuditWorker(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.drift_detector = None
        self.running = False
        self.event_queue = [] # Simple queue for events needing attribution

    def set_drift_detector(self, detector):
        self.drift_detector = detector

    def run(self):
        Logger.info("AuditWorker thread started.")
        self.running = True
        # Simple polling mechanism
        while self.running:
            if self.event_queue:
                event_id, path = self.event_queue.pop(0)
                self._find_and_update_attribution(event_id, path)
            time.sleep(0.5) # Poll every half second
        Logger.info("AuditWorker thread stopped.")

    def stop(self):
        Logger.info("Stopping AuditWorker thread.")
        self.running = False

    def request_attribution(self, event_id, path):
        """Called by the detector to request attribution for an event."""
        self.event_queue.append((event_id, path))

    def _find_and_update_attribution(self, event_id, path):
        """Searches audit log for a matching event and updates the log."""
        try:
            # Use ausearch to find recent events related to the file path
            # The `-k setfop_watches` filters for our specific rules
            cmd = ['ausearch', '-k', 'setfop_watches', '-f', path, '-i']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            
            user = "unknown"
            process = "unknown"

            if result.returncode == 0 and result.stdout:
                # Parse the output to find user and command
                # Example line: 'type=SYSCALL msg=audit(1615624323.123:456): arch=c000003e syscall=268 success=yes exe="/usr/bin/chmod" uid=1000 gid=1000...'
                for line in result.stdout.splitlines():
                    if 'type=SYSCALL' in line:
                        # Find user ID (uid)
                        uid_match = re.search(r'uid=(\d+)', line)
                        if uid_match:
                            uid = uid_match.group(1)
                            user = self._uid_to_username(uid)
                        
                        # Find executable
                        exe_match = re.search(r'exe="([^"]+)"', line)
                        if exe_match:
                            process = os.path.basename(exe_match.group(1))
                        break # We only need the first match

            # Now, update the original log entry with the found attribution
            if self.drift_detector:
                # The detector holds the mapping of event_id to original change details
                change_details = self.drift_detector.get_event_details(event_id)
                if change_details:
                    Logger.update_log_entry(event_id, user, process, change_details['path'], change_details['change'])
                    self.drift_detector.clear_event_details(event_id)

        except FileNotFoundError:
            Logger.error("ausearch command not found. Is auditd installed?")
        except subprocess.TimeoutExpired:
            Logger.error("Audit lookup timed out for path: %s", path)
        except Exception as e:
            Logger.error("Error during audit lookup for %s: %s", path, e)

    def _uid_to_username(self, uid):
        """Converts a UID string to a username."""
        try:
            import pwd
            return pwd.getpwuid(int(uid)).pw_name
        except KeyError:
            return f"uid:{uid}"
        except Exception:
            return "unknown"
