# /opt/setfop-daemon/modules/setfop_daemon_watcher.py
import os
import inotify.adapters
import inotify.constants
from setfop_daemon_logger import Logger

class Watcher:
    def __init__(self, watch_paths, drift_detector):
        self.watch_paths = watch_paths
        self.drift_detector = drift_detector
        self.inotify = inotify.adapters.Inotify()
        self.running = False

    def start(self):
        """Start watching the configured paths."""
        Logger.info("Starting filesystem watcher for paths: %s", ", ".join(self.watch_paths))
        self.running = True
        for path in self.watch_paths:
            if os.path.exists(path):
                self._add_watch_recursive(path)
            else:
                Logger.warning("Watch path does not exist, skipping: %s", path)
        
        # Main event loop
        try:
            for event in self.inotify.event_gen(yield_nones=False):
                if not self.running:
                    break
                if event is not None:
                    header, type_names, watch_path, filename = event
                    # We only care about files, not directories themselves
                    if filename:
                        full_path = os.path.join(watch_path, filename)
                        # Pass the event types to the detector
                        self.drift_detector.process_event(full_path, type_names)
        except Exception as e:
            Logger.error("Error in watcher event loop: %s", e)
            raise

    def stop(self):
        """Stop the watcher."""
        Logger.info("Stopping filesystem watcher.")
        self.running = False

    def _add_watch_recursive(self, path):
        """Recursively add watches for a directory and its subdirectories."""
        try:
            self._add_single_watch(path)
            if os.path.isdir(path):
                for root, dirs, files in os.walk(path):
                    for dir_name in dirs:
                        full_path = os.path.join(root, dir_name)
                        self._add_single_watch(full_path)
        except Exception as e:
            Logger.error("Error adding recursive watch for %s: %s", path, e)

    def _add_single_watch(self, path):
        """Add a watch for a single path."""
        try:
            mask = (
                inotify.constants.IN_CREATE |
                inotify.constants.IN_DELETE |
                inotify.constants.IN_MODIFY |
                inotify.constants.IN_MOVED_FROM |
                inotify.constants.IN_MOVED_TO |
                inotify.constants.IN_ATTRIB # For permission/attribute changes
            )
            self.inotify.add_watch(path, mask=mask)
        except Exception as e:
            Logger.debug("Could not watch %s: %s", path, e)
