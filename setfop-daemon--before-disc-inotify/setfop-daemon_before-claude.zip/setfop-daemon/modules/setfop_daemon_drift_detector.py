# /opt/setfop-daemon/modules/setfop_daemon_drift_detector.py
import os
import stat
import uuid
from setfop_daemon_logger import Logger
from setfop_daemon_utils import get_file_attributes, format_attributes_change

class DriftDetector:
    def __init__(self, baseline_manager, audit_worker):
        self.baseline_manager = baseline_manager
        self.audit_worker = audit_worker
        # Temporary storage for events waiting for audit attribution
        self.pending_events = {} 

    def process_event(self, path, event_types):
        """Main entry point for an event from the watcher."""
        if not os.path.exists(path):
            # Handle deletion
            if path in self.baseline_manager.baseline:
                self._log_deletion(path)
            return

        # Get current state
        current_attrs = get_file_attributes(path)
        
        # Get baseline state
        baseline_attrs = self.baseline_manager.baseline.get(path)

        if not baseline_attrs:
            # New file detected
            self._log_creation(path, current_attrs)
            self.baseline_manager.baseline[path] = current_attrs
        else:
            # Compare to detect drift
            change = self._compare_attributes(baseline_attrs, current_attrs)
            if change:
                self._log_drift(path, change, baseline_attrs, current_attrs)
                # Update baseline to the new state to prevent repeated alerts
                self.baseline_manager.baseline[path] = current_attrs

    def _log_creation(self, path, attrs):
        change_str = "new file"
        user, process = "unknown", "unknown"
        Logger.log_drift(user, process, path, change_str)

    def _log_deletion(self, path):
        change_str = "deleted"
        user, process = "unknown", "unknown"
        Logger.log_drift(user, process, path, change_str)
        # Remove from baseline
        if path in self.baseline_manager.baseline:
            del self.baseline_manager.baseline[path]

    def _log_drift(self, path, change, old_attrs, new_attrs):
        """Logs a drift and requests attribution from the audit worker."""
        # Generate a unique ID for this event
        event_id = str(uuid.uuid4())[:8]
        
        # Store details for the audit worker to find later
        self.pending_events[event_id] = {
            'path': path,
            'change': change
        }

        # Log an initial "unknown" entry immediately
        Logger.log_drift("unknown", "unknown", path, change, event_id=event_id)
        
        # Ask the audit worker to find out who did it
        if self.audit_worker:
            self.audit_worker.request_attribution(event_id, path)

    def _compare_attributes(self, old, new):
        """Compares two attribute dictionaries and returns a formatted change string."""
        changes = []
        if old.get('mode') != new.get('mode'):
            changes.append(f"mode: {old['mode']} → {new['mode']}")
        if old.get('uid') != new.get('uid') or old.get('gid') != new.get('gid'):
            changes.append(f"owner: {old['uid']}:{old['gid']} → {new['uid']}:{new['gid']}")
        if old.get('size') != new.get('size'):
            changes.append(f"size: {old['size']} → {new['size']}")
        if old.get('chattr') != new.get('chattr'):
            changes.append(f"chattr: {old['chattr']} → {new['chattr']}")
        
        return ", ".join(changes)

    # --- Methods for interaction with AuditWorker ---
    def get_event_details(self, event_id):
        return self.pending_events.get(event_id)

    def clear_event_details(self, event_id):
        if event_id in self.pending_events:
            del self.pending_events[event_id]
