# /opt/setfop-daemon/modules/setfop_daemon_watcher.py
import os
import threading
import inotify.adapters
import inotify.constants
from setfop_daemon_utils import get_max_user_watches
from setfop_daemon_logger import Logger

class Watcher:
    def __init__(self, paths, drift_detector):
        self.paths = paths
        self.drift_detector = drift_detector
        self.running = False
        self.thread = None
        self.inotify = inotify.adapters.Inotify() # Start with empty adapter
        self.watched_directories = set()

    def start(self):
        if self.running:
            return
        self.running = True
        
        # Add initial watches from config
        for path in self.paths:
            self._add_watch_recursive(path)

        self.thread = threading.Thread(target=self._watch_loop, daemon=True)
        self.thread.start()
        Logger.info("Filesystem watcher started on: %s", ", ".join(self.paths))

    def _add_watch_recursive(self, path):
        """Recursively adds watches to a directory and all subdirectories."""
        if not os.path.isdir(path):
            self._add_single_watch(path)
            return

        for root, dirs, files in os.walk(path):
            self._add_single_watch(root)

    def _add_single_watch(self, path):
        if path in self.watched_directories:
            return
        try:
            mask = (inotify.constants.IN_ATTRIB | 
                    inotify.constants.IN_MODIFY | 
                    inotify.constants.IN_CREATE | 
                    inotify.constants.IN_DELETE |
                    inotify.constants.IN_MOVED_TO)
            self.inotify.add_watch(path, mask=mask)
            self.watched_directories.add(path)
        except Exception as e:
            Logger.debug("Could not watch %s: %s", path, e)

    def _watch_loop(self):
        try:
            for event in self.inotify.event_gen(yield_nones=False):
                if not self.running:
                    break
                self._handle_event(event)
        except Exception as e:
            Logger.error("Watcher loop error: %s", e)

    def _handle_event(self, event):
        (header, type_names, watch_path, filename) = event
        if not filename:
            return
            
        if isinstance(filename, bytes):
            filename = filename.decode('utf-8')
            
        full_path = os.path.join(watch_path, filename)
        
        # If a new directory is created, watch it automatically
        if "IN_CREATE" in type_names and os.path.isdir(full_path):
            self._add_watch_recursive(full_path)

        try:
            self.drift_detector.process_event(full_path, type_names)
        except Exception as err:
            Logger.error("Error processing %s: %s", full_path, err)

    def stop(self):
        self.running = False
