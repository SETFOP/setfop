# /opt/setfop-daemon/modules/setfop_daemon_audit.py

"""
Audit attribution module for setfop-daemon.

Uses Linux audit logs to determine which user/process
caused a filesystem change.
"""

import subprocess
import threading
import queue
import time

class AuditWorker:
    """
    Background worker that resolves file change attribution
    using auditd.
    """

    def __init__(self):
        self.task_queue = queue.Queue()
        self.running = False
        self.thread = None
        self.max_retries = 3
        self.retry_delay = 0.2
        self.drift_detector = None

    def set_drift_detector(self, drift_detector):
        """
        Connect drift detector so attribution can be returned.
        """
        self.drift_detector = drift_detector

    def start(self):
        """
        Start worker thread.
        """
        if self.running:
            return

        self.running = True
        self.thread = threading.Thread(
            target=self._worker_loop,
            daemon=True
        )
        self.thread.daemon = True  # Add this line
        self.thread.start()

    def stop(self):
        """
        Stop worker thread.
        """
        self.running = False
        if self.thread:
            self.thread.join()

    def submit_task(self, event_id, path):
        """
        Submit attribution lookup task.
        """
        self.task_queue.put((event_id, path))

    def _worker_loop(self):
        """
        Worker processing loop.
        """
        while self.running:
            try:
                event_id, path = self.task_queue.get(timeout=1)
                self._process_task(event_id, path)
                self.task_queue.task_done()
            except queue.Empty:
                continue

    def _process_task(self, event_id, path):
        """
        Attempt to resolve attribution.
        """
        user, process = self._lookup_audit_info(path)
        if user and process and self.drift_detector:
            self.drift_detector.resolve_attribution(
                event_id,
                user,
                process
            )

    def _lookup_audit_info(self, path):
        """
        Query auditd logs using ausearch.
        """
        for attempt in range(self.max_retries):
            try:
                cmd = [
                    "ausearch",
                    "-f",
                    path,
                    "-i",
                    "-ts",
                    "recent"
                ]

                result = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=5
                )

                if result.returncode == 0:
                    user, process = self._parse_audit_output(result.stdout)
                    if user and process:
                        return user, process

                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)

            except Exception:
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)

        return None, None

    def _parse_audit_output(self, output):
        """
        Extract user and process from ausearch output.
        """
        user = None
        process = None

        for line in output.splitlines():
            if "type=SYSCALL" not in line:
                continue

            parts = line.split()
            for part in parts:
                if part.startswith("uid="):
                    uid = part.split("=")[1]
                    try:
                        import pwd
                        user = pwd.getpwuid(int(uid)).pw_name
                    except Exception:
                        user = uid

                if part.startswith("comm="):
                    process = part.split("=")[1].strip('"')

        return user, process
