# /opt/setfop-daemon/modules/setfop_daemon_drift_detector.py

import os
import threading
import time
from setfop_daemon_utils import get_file_attributes, compare_attributes, generate_event_id
from setfop_daemon_logger import Logger

class DriftDetector:
    def __init__(self, baseline_manager, audit_worker):
        self.baseline_manager = baseline_manager
        self.audit_worker = audit_worker
        self.pending_events = {}
        self.lock = threading.Lock()

    def process_event(self, path, event_types):
        if not os.path.exists(path): return

        current_attrs = get_file_attributes(path)
        baseline = self.baseline_manager.get_baseline()
        baseline_attrs = baseline.get(path)

        # Logic Change: Log "New File" instead of silent update
        if not baseline_attrs:
            change_description = "New file detected"
        else:
            differences = compare_attributes(baseline_attrs, current_attrs)
            if not differences: return
            change_description = ", ".join([f"{k}: {v[0]} → {v[1]}" for k, v in differences.items()])

        event_id = generate_event_id()
        
        # Log initial drift
        Logger.log_drift("unknown", "unknown", path, change_description)

        with self.lock:
            self.pending_events[event_id] = {"path": path, "change": change_description}

        # Update baseline and seek attribution
        self.baseline_manager.update_path(path)
        self.audit_worker.submit_task(event_id, path)
