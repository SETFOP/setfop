# /opt/setfop-daemon/modules/setfop_daemon_logger.py
import logging
import os
import threading


class Logger:
    _logger = None
    _log_file = ""
    _lock = threading.Lock()

    @classmethod
    def initialize(cls, log_file, level):
        cls._log_file = log_file

        numeric_level = getattr(logging, level.upper(), None)
        if not isinstance(numeric_level, int):
            raise ValueError(f"Invalid log level: {level}")

        os.makedirs(os.path.dirname(log_file), exist_ok=True)

        logging.basicConfig(
            level=numeric_level,
            format="%(asctime)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(),
            ]
        )
        cls._logger = logging.getLogger("setfop")

    @classmethod
    def log_drift(cls, user, process, path, change):
        """
        Write a drift log entry with known actor.

        Format: TIMESTAMP | user -> process | path | change

        This is always the final entry — no placeholders, no rewrites.
        """
        with cls._lock:
            cls._logger.info("%s -> %s | %s | %s", user, process, path, change)

    @classmethod
    def log_drift_unknown(cls, path, change):
        """
        Write a drift log entry where the actor could not be determined.

        Format: TIMESTAMP | unknown | path | change

        Used when attribution returns ("unknown", "unknown") — the single
        'unknown' field signals clearly that the actor is unresolved,
        as opposed to 'unknown -> unknown' which implies two unknowns.
        """
        with cls._lock:
            cls._logger.info("unknown | %s | %s", path, change)

    @classmethod
    def info(cls, msg, *args):
        cls._logger.info(msg, *args)

    @classmethod
    def warning(cls, msg, *args):
        cls._logger.warning(msg, *args)

    @classmethod
    def error(cls, msg, *args):
        cls._logger.error(msg, *args)

    @classmethod
    def debug(cls, msg, *args):
        cls._logger.debug(msg, *args)
