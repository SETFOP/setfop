# /opt/setfop-daemon/modules/setfop_daemon_drift_detector.py
import os
import threading
from setfop_daemon_utils import get_file_attributes, compare_attributes, generate_event_id
from setfop_daemon_logger import Logger

class DriftDetector:
    def __init__(self, baseline_manager, audit_worker):
        self.baseline_manager = baseline_manager
        self.audit_worker = audit_worker
        self.pending_events = {}
        self.lock = threading.Lock()

    def process_event(self, path, event_types):
        if not os.path.exists(path):
            if "IN_DELETE" in event_types:
                Logger.log_drift("unknown", "rm", path, "deleted")
            return

        current_attrs = get_file_attributes(path)
        baseline = self.baseline_manager.get_baseline()
        baseline_attrs = baseline.get(path)

        # Handle New Files
        if not baseline_attrs:
            Logger.log_drift("unknown", "unknown", path, "new file")
            self.baseline_manager.update_path(path)
            return

        differences = compare_attributes(baseline_attrs, current_attrs)
        if not differences:
            return

        for attr, (old_val, new_val) in differences.items():
            change_desc = f"{attr}: {old_val} → {new_val}"
            event_id = generate_event_id()
            
            # Log with 'unknown' but track the event_id for later replacement
            Logger.log_drift("unknown", "unknown", path, change_desc, event_id=event_id)

            with self.lock:
                self.pending_events[event_id] = {
                    "path": path, 
                    "change": change_desc
                }
            
            # Submit to AuditWorker to find the real user/process
            self.audit_worker.submit_task(event_id, path)
        
        self.baseline_manager.update_path(path)

    def resolve_attribution(self, event_id, user, process):
        """Called by AuditWorker when auditd data is found."""
        with self.lock:
            if event_id in self.pending_events:
                event = self.pending_events[event_id]
                # Tell logger to update the existing line for this event_id
                Logger.update_log_entry(event_id, user, process, event["path"], event["change"])
                del self.pending_events[event_id]
