import subprocess
import threading
import queue
import time
from setfop_daemon_logger import Logger

class AuditWorker:
    def __init__(self):
        self.task_queue = queue.Queue()
        self.running = False
        self.drift_detector = None

    def set_drift_detector(self, detector):
        self.drift_detector = detector

    def start(self):
        self.running = True
        threading.Thread(target=self._worker_loop, daemon=True).start()

    def submit_task(self, event_id, path):
        self.task_queue.put((event_id, path))

    def _worker_loop(self):
        while self.running:
            try:
                event_id, path = self.task_queue.get(timeout=1)
                # Query auditd for the most recent syscall on this path
                # 'ausearch -f' is precise but can be slow; we limit to last 10 mins
                cmd = ["ausearch", "-f", path, "-ts", "recent", "-i"]
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                user, process = "unknown", "unknown"
                
                if result.returncode == 0:
                    for line in result.stdout.splitlines():
                        if "type=SYSCALL" in line:
                            # Extract user (auid/uid) and command (exe/comm)
                            parts = line.split()
                            for p in parts:
                                if p.startswith("auid="): user = p.split("=")[1]
                                if p.startswith("exe="): process = p.split("=")[1].strip('"')

                if self.drift_detector:
                    self.drift_detector.resolve_attribution(event_id, user, process)
                
            except queue.Empty:
                continue
            except Exception as e:
                Logger.error(f"Audit lookup failed: {e}")

    def stop(self):
        self.running = False
