#!/usr/bin/env python3
"""
Baseline management module for setfop-daemon.
Optimized for atomic persistence and interruptible scanning.
"""

import os
import json
import threading
import time
import tempfile

from setfop_daemon_utils import get_file_attributes

class BaselineManager:
    """
    Manages baseline snapshot of filesystem attributes.
    """

    def __init__(self, baseline_file):
        self.baseline_file = baseline_file
        self.baseline = {}
        self.lock = threading.Lock()
        self.last_persist_time = 0
        self.persist_interval = 30
        
        # Ensure directory exists
        base_dir = os.path.dirname(self.baseline_file)
        if base_dir and not os.path.exists(base_dir):
            os.makedirs(base_dir, exist_ok=True)

    def load_baseline(self):
        """
        Load baseline snapshot from disk with error handling.
        """
        with self.lock:
            if not os.path.exists(self.baseline_file):
                self.baseline = {}
                return

            try:
                with open(self.baseline_file, "r") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.baseline = data
            except (json.JSONDecodeError, IOError):
                # If file is corrupted, start fresh rather than crashing
                self.baseline = {}

    def persist_baseline(self):
        """
        Persist baseline snapshot to disk atomically.
        Uses a temporary file to prevent corruption during crashes.
        """
        with self.lock:
            try:
                base_dir = os.path.dirname(self.baseline_file)
                # Create a temp file in the same directory
                with tempfile.NamedTemporaryFile('w', dir=base_dir, delete=False) as tf:
                    json.dump(self.baseline, tf, indent=2)
                    temp_name = tf.name
                
                # Atomic rename (overwrites destination safely)
                os.replace(temp_name, self.baseline_file)
                self.last_persist_time = time.time()
            except Exception:
                # Log this if your Logger is available, or just pass to avoid daemon crash
                if os.path.exists(temp_name):
                    os.remove(temp_name)

    def create_baseline(self, paths):
        """
        Build initial baseline snapshot.
        """
        # Note: We don't hold the lock for the whole scan to allow 
        # other logic to breathe, but we clear the baseline first.
        with self.lock:
            self.baseline = {}
        
        for path in paths:
            self._add_path_recursive(path)
        
        self.persist_baseline()

    def update_path(self, path):
        """
        Update baseline entry for a single path.
        """
        with self.lock:
            attributes = get_file_attributes(path)
            if attributes:
                self.baseline[path] = attributes
            else:
                self.baseline.pop(path, None)

            if time.time() - self.last_persist_time > self.persist_interval:
                # We release the lock briefly for persistence
                pass 
        
        # Persist if needed
        if time.time() - self.last_persist_time > self.persist_interval:
            self.persist_baseline()

    def _add_path_recursive(self, path):
        """
        Add path and contents to baseline using an efficient walk.
        """
        if not os.path.exists(path):
            return

        # Add the root path itself
        attrs = get_file_attributes(path)
        if attrs:
            with self.lock:
                self.baseline[path] = attrs

        if os.path.isdir(path):
            try:
                for root, dirs, files in os.walk(path):
                    # Batch processing for efficiency
                    current_batch = {}
                    
                    for item in dirs + files:
                        full_path = os.path.join(root, item)
                        item_attrs = get_file_attributes(full_path)
                        if item_attrs:
                            current_batch[full_path] = item_attrs
                    
                    # Merge batch into baseline with a single lock acquisition
                    with self.lock:
                        self.baseline.update(current_batch)
                        
            except Exception:
                pass

    def get_baseline(self):
        """
        Return copy of baseline snapshot.
        """
        with self.lock:
            return dict(self.baseline)

    def get_directories(self):
        """
        Return list of directories currently in baseline.
        """
        with self.lock:
            return [path for path, attrs in self.baseline.items() 
                    if os.path.isdir(path)]