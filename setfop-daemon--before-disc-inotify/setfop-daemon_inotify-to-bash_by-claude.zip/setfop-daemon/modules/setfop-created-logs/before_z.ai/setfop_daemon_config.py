# /opt/setfop-daemon/modules/setfop_daemon_config.py

import os

class Config:
    def __init__(self):
        self.version = "1.1.0"
        self.config_file = "/etc/setfop/setfop-daemon.config"
        self.log_file = "/var/log/setfop/drift.log"
        self.baseline_file = "/var/lib/setfop/baseline.setfop"
        self.log_level = "INFO"

        # Explicitly forbidden paths (Kernel/Temp/System)
        self.forbidden_prefixes = [
            "/proc", "/sys", "/dev", "/run", "/tmp", 
            "/var/tmp", "/dev/shm"
        ]
        
        # Forbidden filesystem types
        self.forbidden_fstypes = ["proc", "sysfs", "tmpfs", "devtmpfs", "overlay"]

        # Default paths to monitor if config is missing
        self.watch_paths = ["/etc", "/opt", "/var/www"]

        self._load_config()
        self.watch_paths = self._sanitize_paths(self.watch_paths)

    def _sanitize_paths(self, paths):
        """
        Implements hierarchy logic and removes forbidden system paths.
        """
        # 1. Remove forbidden paths and normalize
        clean_paths = []
        for p in paths:
            p = os.path.abspath(p.strip())
            if any(p.startswith(forbidden) for forbidden in self.forbidden_prefixes):
                continue
            clean_paths.append(p)

        # 2. Sort by length to handle hierarchy (shorter paths first)
        clean_paths = sorted(list(set(clean_paths)), key=len)
        
        # 3. Hierarchy Logic: If /usr exists, ignore /usr/bin
        final_paths = []
        for p in clean_paths:
            # Check if this path is a sub-path of any path already accepted
            is_redundant = False
            for parent in final_paths:
                # Check if p is inside parent (e.g., /usr/bin starts with /usr/)
                if p.startswith(parent.rstrip('/') + '/'):
                    is_redundant = True
                    break
            
            if not is_redundant:
                final_paths.append(p)
        
        return final_paths

    def _load_config(self):
        if not os.path.exists(self.config_file):
            return
        try:
            with open(self.config_file) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, value = line.split("=", 1)
                    key, value = key.strip(), value.strip()

                    if key == "log_level":
                        self.log_level = value
                    elif key == "watch_paths":
                        self.watch_paths = [p.strip() for p in value.split(",") if p.strip()]
        except Exception:
            pass
