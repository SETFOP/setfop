# /opt/setfop-daemon/modules/setfop_daemon_utils.py
import os
import subprocess
import uuid
import pwd
import grp

def get_max_user_watches():
    """Return Linux inotify watch limit from procfs."""
    try:
        with open("/proc/sys/fs/inotify/max_user_watches", "r") as f:
            return int(f.read().strip())
    except Exception:
        return 8192

def get_file_attributes(path):
    """Collects mode, owner, chattr, and security contexts."""
    try:
        stat = os.stat(path)
        user = pwd.getpwuid(stat.st_uid).pw_name
        group = grp.getgrgid(stat.st_gid).gr_name
        
        attributes = {
            "mode": oct(stat.st_mode)[-4:],
            "owner": f"{user}:{group}",
            "size": stat.st_size,
        }

        # Get chattr flags
        try:
            attr_out = subprocess.check_output(["lsattr", "-d", path], stderr=subprocess.DEVNULL)
            attributes["chattr"] = attr_out.decode().split()[0]
        except:
            attributes["chattr"] = "----------------"

        # Get SELinux / Context
        try:
            selinux = subprocess.check_output(["getfattr", "-n", "security.selinux", "--only-values", path], stderr=subprocess.DEVNULL)
            attributes["context"] = selinux.decode().strip()
        except:
            attributes["context"] = "unconfined"

        return attributes
    except:
        return None

def compare_attributes(old, new):
    diffs = {}
    for key in old:
        if key in new and old[key] != new[key]:
            diffs[key] = (old[key], new[key])
    return diffs

def generate_event_id():
    return str(uuid.uuid4())[:8]
