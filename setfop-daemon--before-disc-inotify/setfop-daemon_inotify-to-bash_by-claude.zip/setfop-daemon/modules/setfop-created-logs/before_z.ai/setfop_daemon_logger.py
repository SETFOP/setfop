import logging
import datetime
import os

class Logger:
    _logger = None
    _log_file = ""

    @classmethod
    def initialize(cls, log_file, level):
        cls._log_file = log_file
        numeric_level = getattr(logging, level.upper(), None)
        logging.basicConfig(
            level=numeric_level,
            format='%(asctime)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        cls._logger = logging.getLogger("setfop")

    @classmethod
    def log_drift(cls, user, process, path, change, event_id=None):
        """Standard drift log entry."""
        eid_str = f" [{event_id}]" if event_id else ""
        msg = f"{user} -> {process} | {path} | {change}{eid_str}"
        cls._logger.info(msg)

    @classmethod
    def update_log_entry(cls, event_id, user, process, path, change):
        """
        Replaces the 'unknown' line with real data to avoid duplication.
        """
        if not os.path.exists(cls._log_file):
            return
            
        lines = []
        target_marker = f"[{event_id}]"
        updated = False
        
        with open(cls._log_file, 'r') as f:
            lines = f.readlines()
            
        with open(cls._log_file, 'w') as f:
            for line in lines:
                if target_marker in line:
                    timestamp = line.split('|')[0].strip()
                    f.write(f"{timestamp} | {user} -> {process} | {path} | {change}\n")
                    updated = True
                else:
                    f.write(line)
        
        if updated:
            logging.debug(f"Updated event {event_id} with attribution.")

    @classmethod
    def info(cls, msg, *args): cls._logger.info(msg, *args)
    @classmethod
    def error(cls, msg, *args): cls._logger.error(msg, *args)
