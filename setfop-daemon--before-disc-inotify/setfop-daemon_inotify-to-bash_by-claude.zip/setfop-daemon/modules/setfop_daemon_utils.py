# /opt/setfop-daemon/modules/setfop_daemon_utils.py
import os
import stat
import subprocess
import pwd
import grp


def get_file_attributes(path):
    """
    Returns a dict of file attributes for path, or None on error.

    Keys:
        mode   (str)       - 4-digit octal string e.g. "0755"
        owner  (str)       - "username:groupname" e.g. "root:vamsiva"
        size   (int)       - file size in bytes
        chattr (str|None)  - lsattr flag string e.g. "----e----i------"
                             None if lsattr unavailable or failed
    """
    try:
        stat_info = os.lstat(path)

        try:
            uname = pwd.getpwuid(stat_info.st_uid).pw_name
        except KeyError:
            uname = str(stat_info.st_uid)

        try:
            gname = grp.getgrgid(stat_info.st_gid).gr_name
        except KeyError:
            gname = str(stat_info.st_gid)

        mode_digits = oct(stat.S_IMODE(stat_info.st_mode))[2:]
        mode_str = "0" + mode_digits.zfill(3)

        return {
            "mode":   mode_str,
            "owner":  f"{uname}:{gname}",
            "size":   stat_info.st_size,
            "chattr": get_chattr_flags(path),
        }
    except FileNotFoundError:
        return None
    except Exception as e:
        print(f"[setfop] get_file_attributes error for {path}: {e}")
        return None


def get_chattr_flags(path):
    """
    Returns the raw lsattr flag string for path (e.g. "----e----i------").

    Returns None if lsattr is not installed, path does not exist,
    or output cannot be parsed.

    Never returns a fabricated fallback string. Callers must treat
    None as "could not determine" and skip the chattr field entirely.
    """
    try:
        result = subprocess.run(
            ["lsattr", "-d", path],
            capture_output=True,
            text=True,
            timeout=3
        )
        if result.returncode != 0:
            return None

        parts = result.stdout.strip().split()
        if not parts:
            return None

        flags = parts[0]
        if len(flags) < 4:  # basic sanity
            return None

        return flags

    except FileNotFoundError:
        return None  # lsattr not installed
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def diff_chattr_flags(old_flags, new_flags):
    """
    Compares two lsattr flag strings and returns a human-readable diff
    showing only what changed, e.g. "+i", "-i", "+i+a".

    Returns None if strings are identical or either is None.
    This diff string is what goes in the log — not the full flag dump.

    Flag character order follows e2fsprogs lsattr convention:
      position 0  -> s (secure deletion)
      position 1  -> u (undeletable)
      position 2  -> S (sync)
      position 3  -> i (immutable)       <- most common
      position 4  -> a (append-only)     <- common
      position 5  -> A (no atime)
      position 6  -> j (journalled data)
      position 7  -> d (no dump)
      position 8  -> t (no tail-merging)
      position 9  -> T (top of dir hier)
      position 10 -> e (extents)         <- always set on ext4
      position 11 -> C (no COW)
      position 12 -> N (inline data)
      position 13 -> E (encrypted)
      position 14 -> I (indexed dir)
      position 15 -> V (verity)
    """
    if old_flags is None or new_flags is None:
        return None
    if old_flags == new_flags:
        return None

    flag_names = "suSiaAjdtTeCNEIV"

    max_len = max(len(old_flags), len(new_flags))
    old_p = old_flags.ljust(max_len, '-')
    new_p = new_flags.ljust(max_len, '-')

    added   = []
    removed = []

    for idx, (o, n) in enumerate(zip(old_p, new_p)):
        if o == n:
            continue
        fname = flag_names[idx] if idx < len(flag_names) else "?"
        if o == '-' and n != '-':
            added.append(fname)
        elif o != '-' and n == '-':
            removed.append(fname)

    parts = []
    if added:
        parts.append("+" + "".join(added))
    if removed:
        parts.append("-" + "".join(removed))

    return "".join(parts) if parts else None


def get_max_user_watches():
    """Return Linux inotify watch limit from procfs."""
    try:
        with open("/proc/sys/fs/inotify/max_user_watches", "r") as f:
            return int(f.read().strip())
    except Exception:
        return 8192
