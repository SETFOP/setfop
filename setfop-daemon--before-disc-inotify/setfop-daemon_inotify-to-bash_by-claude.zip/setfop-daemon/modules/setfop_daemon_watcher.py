# /opt/setfop-daemon/modules/setfop_daemon_watcher.py
import os
import threading
import time

import inotify.adapters
import inotify.constants

from setfop_daemon_logger import Logger
from setfop_daemon_audit import register_auditd_rules, remove_auditd_rules
from setfop_daemon_utils import get_chattr_flags

# How often the chattr poller scans all baseline entries (seconds)
CHATTR_POLL_INTERVAL = 15


class Watcher:
    def __init__(self, watch_paths, drift_detector):
        self.watch_paths = watch_paths
        self.drift_detector = drift_detector
        self.inotify = inotify.adapters.Inotify()
        self.running = False
        self._chattr_thread = None

    def start(self):
        Logger.info("Starting filesystem watcher for paths: %s", ", ".join(self.watch_paths))
        self.running = True

        # Register auditd rules so ausearch attribution works
        register_auditd_rules(self.watch_paths)

        # Add inotify watches
        for path in self.watch_paths:
            if os.path.exists(path):
                self._add_watch_recursive(path)
            else:
                Logger.warning("Watch path does not exist, skipping: %s", path)

        # Start chattr poller as a background daemon thread
        self._chattr_thread = threading.Thread(
            target=self._chattr_poll_loop,
            daemon=True,
            name="ChattrPoller"
        )
        self._chattr_thread.start()
        Logger.info("ChattrPoller started (interval: %ds).", CHATTR_POLL_INTERVAL)

        # Main inotify event loop — blocks until stop() sets running=False
        try:
            for event in self.inotify.event_gen(yield_nones=False):
                if not self.running:
                    break
                if event is not None:
                    header, type_names, watch_path, filename = event
                    if filename:
                        full_path = os.path.join(watch_path, filename)
                        self.drift_detector.process_event(full_path, type_names)
        except Exception as e:
            Logger.error("Error in watcher event loop: %s", e)
            raise

    def stop(self):
        Logger.info("Stopping filesystem watcher.")
        self.running = False
        remove_auditd_rules()

    # ------------------------------------------------------------------ #
    #  chattr poller                                                       #
    # ------------------------------------------------------------------ #

    def _chattr_poll_loop(self):
        """
        Background thread: every CHATTR_POLL_INTERVAL seconds, scan all
        baseline entries and check whether chattr flags have drifted.

        inotify is blind to FS_IOC_SETFLAGS (the ioctl used by chattr),
        so this polling loop is the only detection mechanism.

        Known limitation: if someone sets +i then removes -i within one
        interval, the net change is zero and it will not be logged.
        This is documented and accepted — we never fabricate a log entry.
        """
        while self.running:
            # Sleep in small steps so stop() is responsive
            for _ in range(CHATTR_POLL_INTERVAL * 4):
                if not self.running:
                    return
                time.sleep(0.25)

            if not self.running:
                return

            try:
                self._poll_chattr_once()
            except Exception as e:
                Logger.error("ChattrPoller error: %s", e)

    def _poll_chattr_once(self):
        """
        Single poll pass: compare current lsattr flags against baseline.
        Passes confirmed changes to DriftDetector.process_chattr_event().
        """
        snapshot = self.drift_detector.baseline_manager.get_baseline()

        for path, baseline_attrs in snapshot.items():
            if not os.path.exists(path) or os.path.isdir(path):
                continue

            baseline_flags = baseline_attrs.get("chattr")
            if baseline_flags is None:
                # Baseline was built without chattr — skip, not an error
                continue

            current_flags = get_chattr_flags(path)

            # get_chattr_flags returns None on any error — never log uncertain data
            if current_flags is None:
                continue

            if current_flags != baseline_flags:
                self.drift_detector.process_chattr_event(
                    path,
                    old_flags=baseline_flags,
                    new_flags=current_flags
                )

    # ------------------------------------------------------------------ #
    #  inotify helpers                                                     #
    # ------------------------------------------------------------------ #

    def _add_watch_recursive(self, path):
        try:
            self._add_single_watch(path)
            if os.path.isdir(path):
                for root, dirs, files in os.walk(path):
                    for dir_name in dirs:
                        self._add_single_watch(os.path.join(root, dir_name))
        except Exception as e:
            Logger.error("Error adding recursive watch for %s: %s", path, e)

    def _add_single_watch(self, path):
        try:
            mask = (
                inotify.constants.IN_CREATE    |
                inotify.constants.IN_DELETE    |
                inotify.constants.IN_MODIFY    |
                inotify.constants.IN_MOVED_FROM |
                inotify.constants.IN_MOVED_TO  |
                inotify.constants.IN_ATTRIB      # chmod/chown — NOT chattr
            )
            self.inotify.add_watch(path, mask=mask)
        except Exception as e:
            Logger.debug("Could not watch %s: %s", path, e)
