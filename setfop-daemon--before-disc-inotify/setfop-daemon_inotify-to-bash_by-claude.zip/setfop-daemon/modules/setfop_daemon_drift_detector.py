# /opt/setfop-daemon/modules/setfop_daemon_drift_detector.py
import os

from setfop_daemon_logger import Logger
from setfop_daemon_utils import get_file_attributes, diff_chattr_flags
from setfop_daemon_audit import lookup_actor


class DriftDetector:
    def __init__(self, baseline_manager, audit_worker=None):
        self.baseline_manager = baseline_manager
        # audit_worker retained for API compatibility with main.py
        self.audit_worker = audit_worker

    # ------------------------------------------------------------------ #
    #  inotify event entry point                                          #
    # ------------------------------------------------------------------ #

    def process_event(self, path, event_types):
        """Called by Watcher for every inotify event."""

        if not os.path.exists(path):
            if "IN_DELETE" in event_types or "IN_MOVED_FROM" in event_types:
                self._handle_deletion(path)
            return

        current_attrs = get_file_attributes(path)
        if current_attrs is None:
            return

        baseline = self.baseline_manager.get_baseline()
        baseline_attrs = baseline.get(path)

        if baseline_attrs is None:
            self._handle_new_file(path)
            return

        self._handle_drift(path, baseline_attrs, current_attrs)

    # ------------------------------------------------------------------ #
    #  chattr poller entry point                                          #
    # ------------------------------------------------------------------ #

    def process_chattr_event(self, path, old_flags, new_flags):
        """
        Called by ChattrPoller when lsattr flags differ from baseline.

        chattr uses FS_IOC_SETFLAGS ioctl which inotify cannot see,
        so the poller is the only detection mechanism.

        Attribution is best-effort: by poll time the process has likely
        exited. We try anyway with a short timeout — if auditd has a
        recent record we log the actor, otherwise we log 'unknown'.
        We never fabricate an actor.

        Log format for chattr:
            user -> chattr | path | chattr: --> +i        (if actor known)
            unknown | path | chattr: --> -i               (if actor unknown)
        """
        flag_diff = diff_chattr_flags(old_flags, new_flags)
        if flag_diff is None:
            return  # flags are identical, nothing to log

        change_desc = f"chattr: --> {flag_diff}"

        # Short wait — event is already stale by poll interval
        user, process = lookup_actor(path, max_wait=1.0)
        _log(user, process, path, change_desc)

        self.baseline_manager.update_path(path)

    # ------------------------------------------------------------------ #
    #  internal handlers                                                  #
    # ------------------------------------------------------------------ #

    def _handle_new_file(self, path):
        user, process = lookup_actor(path)
        _log(user, process, path, "new file")
        self.baseline_manager.update_path(path)

    def _handle_deletion(self, path):
        user, process = lookup_actor(path)
        _log(user, process, path, "deleted")
        self.baseline_manager.update_path(path)

    def _handle_drift(self, path, baseline_attrs, current_attrs):
        """
        Compare baseline vs current, log each change individually.
        chattr diffs are skipped here — owned by the ChattrPoller.
        """
        changes = _compare_attributes(baseline_attrs, current_attrs)
        if not changes:
            return

        # Single attribution lookup per file event — not per field
        user, process = lookup_actor(path)

        for attr, (old_val, new_val) in changes.items():
            change_desc = _format_change(attr, old_val, new_val)

            if attr == "owner":
                # Ownership change: actor slot shows old_owner -> new_owner per spec.
                # The person who ran chown/chgrp is recorded in change_desc itself.
                Logger.log_drift(old_val, new_val, path, change_desc)
            else:
                _log(user, process, path, change_desc)

        self.baseline_manager.update_path(path)


# ------------------------------------------------------------------ #
#  attribute comparison helpers                                        #
# ------------------------------------------------------------------ #

def _log(user, process, path, change):
    """
    Route to the correct log method based on whether actor is known.

    Known actor  → TIMESTAMP | user -> process | path | change
    Unknown actor → TIMESTAMP | unknown | path | change

    The 'unknown -> unknown' format is never used — it's misleading
    because it implies two separate unknowns when really we just
    couldn't determine who acted.
    """
    if user != "unknown":
        Logger.log_drift(user, process, path, change)
    else:
        Logger.log_drift_unknown(path, change)


def _normalise_owner(attrs):
    """
    Baseline entries built by the old code stored uid/gid as separate
    integer keys. New code stores a single 'owner' string "name:name".

    This normalises old-format entries so comparisons work correctly
    during the transition period (until the baseline is rebuilt).
    """
    if "owner" in attrs:
        return attrs  # already new format

    import pwd, grp
    uid = attrs.get("uid")
    gid = attrs.get("gid")
    if uid is None or gid is None:
        return attrs

    try:
        uname = pwd.getpwuid(int(uid)).pw_name
    except Exception:
        uname = str(uid)
    try:
        gname = grp.getgrgid(int(gid)).gr_name
    except Exception:
        gname = str(gid)

    # Return a copy with the unified owner field
    normalised = dict(attrs)
    normalised["owner"] = f"{uname}:{gname}"
    return normalised


def _normalise_mode(val):
    """
    Normalise mode to a 4-digit octal string with leading zero.
    Handles old baseline entries stored without the leading zero.
    e.g. "644" -> "0644", "0644" -> "0644"
    """
    if val is None:
        return val
    s = str(val).lstrip("0") or "0"
    return "0" + s.zfill(3)


def _compare_attributes(old, new):
    """
    Returns dict of {attr: (old_val, new_val)} for changed attributes.
    Skips chattr — handled exclusively by the ChattrPoller.

    Normalises old integer-keyed baseline entries on the fly so the
    daemon works correctly even before the baseline is rebuilt.
    """
    old = _normalise_owner(old)
    new = _normalise_owner(new)

    diffs = {}

    # mode — normalise both sides before comparing
    old_mode = _normalise_mode(old.get("mode"))
    new_mode = _normalise_mode(new.get("mode"))
    if old_mode and new_mode and old_mode != new_mode:
        diffs["mode"] = (old_mode, new_mode)

    # owner (covers both chown and chgrp — both change the owner string)
    o_owner = old.get("owner")
    n_owner = new.get("owner")
    if o_owner and n_owner and o_owner != n_owner:
        diffs["owner"] = (o_owner, n_owner)

    # size
    o_size = old.get("size")
    n_size = new.get("size")
    if o_size is not None and n_size is not None and o_size != n_size:
        diffs["size"] = (o_size, n_size)

    return diffs


def _format_change(attr, old_val, new_val):
    if attr == "mode":
        return f"mode: {old_val} → {new_val}"
    if attr == "owner":
        return f"owner: {old_val} → {new_val}"
    if attr == "size":
        return f"size: {old_val} → {new_val}"
    return f"{attr}: {old_val} → {new_val}"
