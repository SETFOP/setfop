# /opt/setfop-daemon/modules/setfop_daemon_audit.py
import os
import re
import pwd
import subprocess
import time

from setfop_daemon_logger import Logger

AUDIT_KEY = "setfop_watches"


# ------------------------------------------------------------------ #
#  AuditWorker — stub retained so main.py import/calls don't break   #
#  Attribution is now synchronous inside DriftDetector               #
# ------------------------------------------------------------------ #

class AuditWorker:
    def __init__(self):
        self.drift_detector = None
        self.running = False

    def set_drift_detector(self, detector):
        self.drift_detector = detector

    def start(self):
        Logger.info("AuditWorker thread started.")
        self.running = True

    def stop(self):
        self.running = False

    def request_attribution(self, event_id, path):
        # No-op: attribution is now done synchronously in DriftDetector
        pass


# ------------------------------------------------------------------ #
#  auditd rule management                                             #
# ------------------------------------------------------------------ #

def register_auditd_rules(watch_paths):
    """
    Register auditd watch rules for all active watch paths.
    Called once at daemon startup by the Watcher.

    Flushes any leftover rules from a previous (possibly unclean) shutdown
    before adding new ones — prevents the "Rule exists" error.
    Failures are warned but never crash the daemon — attribution
    will fall back to 'unknown' gracefully.
    """
    # Flush any stale rules from a previous run before adding new ones.
    # This is safe — we own all rules under AUDIT_KEY.
    _flush_auditd_rules(watch_paths)

    for path in watch_paths:
        if not os.path.exists(path):
            continue
        try:
            cmd = ["auditctl", "-w", path, "-p", "rwxa", "-k", AUDIT_KEY]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if result.returncode != 0:
                Logger.warning("auditctl rule failed for %s: %s", path, result.stderr.strip())
            else:
                Logger.info("auditd rule registered for: %s", path)
        except FileNotFoundError:
            Logger.warning("auditctl not found — actor attribution will be 'unknown'")
            return
        except Exception as e:
            Logger.warning("Could not register auditd rule for %s: %s", path, e)


def _flush_auditd_rules(watch_paths):
    """
    Remove any existing auditd watch rules for our paths under AUDIT_KEY.
    Called before re-registering to avoid 'Rule exists' errors on restart.
    Silently ignores errors — if there's nothing to remove, that's fine.
    """
    for path in watch_paths:
        try:
            # -W removes a specific watch rule; fails silently if not present
            subprocess.run(
                ["auditctl", "-W", path, "-p", "rwxa", "-k", AUDIT_KEY],
                capture_output=True, text=True, timeout=5
            )
        except Exception:
            pass


def remove_auditd_rules():
    """
    Remove all setfop auditd rules on daemon shutdown.
    Reads current rules to find which paths to remove.
    """
    try:
        result = subprocess.run(
            ["auditctl", "-l"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return
        for line in result.stdout.splitlines():
            if AUDIT_KEY not in line:
                continue
            match = re.search(r'-w\s+(\S+)', line)
            if match:
                path = match.group(1)
                subprocess.run(
                    ["auditctl", "-W", path, "-p", "rwxa", "-k", AUDIT_KEY],
                    capture_output=True, text=True, timeout=5
                )
    except Exception:
        pass


# ------------------------------------------------------------------ #
#  Synchronous actor lookup                                           #
# ------------------------------------------------------------------ #

def lookup_actor(path, max_wait=2.0, poll_interval=0.25):
    """
    Synchronously look up who last touched `path` via ausearch.

    Polls up to max_wait seconds in poll_interval steps to give
    auditd time to flush the record.

    Returns (username, process_name).
    Returns ("unknown", "unknown") if attribution cannot be confirmed —
    never returns a guess.

    Design principle: callers write exactly one log entry after this
    returns. No placeholders. No rewrites.
    """
    deadline = time.monotonic() + max_wait

    while time.monotonic() < deadline:
        user, process = _query_ausearch(path)
        if user != "unknown":
            return user, process
        time.sleep(poll_interval)

    return "unknown", "unknown"


def _query_ausearch(path):
    """
    Run ausearch for the most recent setfop_watches event touching path.
    Returns (username, process_name) or ("unknown", "unknown").
    """
    try:
        # -ts recent = last 10 minutes; --just-one = most recent match only
        # -i = interpret UIDs/GIDs to names where possible
        cmd = ["ausearch", "-k", AUDIT_KEY, "--just-one", "-i", "-ts", "recent"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=3)

        if result.returncode != 0 or not result.stdout.strip():
            return "unknown", "unknown"

        # ausearch output: blocks of lines separated by "----" or blank lines
        blocks = re.split(r'\n----\n|\n\n', result.stdout.strip())

        # Walk blocks from most recent (last) to oldest, find one for our path
        target_block = None
        for block in reversed(blocks):
            if path in block:
                target_block = block
                break

        if not target_block:
            return "unknown", "unknown"

        user    = "unknown"
        process = "unknown"

        for line in target_block.splitlines():
            if "type=SYSCALL" not in line:
                continue

            # auid = audit login UID — survives su/sudo, prefer over uid
            auid_match = re.search(r'\bauid=(\S+)', line)
            uid_match  = re.search(r'\buid=(\S+)',  line)
            exe_match  = re.search(r'\bexe="([^"]+)"', line)
            comm_match = re.search(r'\bcomm="([^"]+)"', line)

            raw_auid = auid_match.group(1) if auid_match else None
            raw_uid  = uid_match.group(1)  if uid_match  else None

            # auid 4294967295 / -1 / "unset" means no login session (kernel/daemon)
            if raw_auid and raw_auid not in ("4294967295", "-1", "unset"):
                user = _resolve_uid(raw_auid)
            elif raw_uid:
                user = _resolve_uid(raw_uid)

            if exe_match:
                process = os.path.basename(exe_match.group(1))
            elif comm_match:
                process = comm_match.group(1)

            break  # first SYSCALL line is sufficient

        return user, process

    except subprocess.TimeoutExpired:
        return "unknown", "unknown"
    except Exception as e:
        Logger.debug("ausearch query error: %s", e)
        return "unknown", "unknown"


def _resolve_uid(raw):
    """
    Convert a uid value to a username.
    ausearch -i often resolves it already; if it's not a digit, trust it.
    """
    if not str(raw).isdigit():
        # Already resolved by ausearch -i, or a name string
        return raw if raw not in ("unset", "-1") else "unknown"
    try:
        return pwd.getpwuid(int(raw)).pw_name
    except KeyError:
        return f"uid:{raw}"
    except Exception:
        return "unknown"
