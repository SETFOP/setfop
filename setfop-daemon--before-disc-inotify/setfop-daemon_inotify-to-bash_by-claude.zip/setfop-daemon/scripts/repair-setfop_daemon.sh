#!/bin/bash

set -e

REPO_URL="https://github.com/example/setfop-daemon/archive/refs/heads/main.tar.gz"

INSTALL_DIR="/opt/setfop-daemon"
LOG_DIR="/var/log/setfop"
CONFIG_DIR="/etc/setfop"
LIB_DIR="/var/lib/setfop"

echo "[INFO] Repairing setfop-daemon..."

if [[ $EUID -ne 0 ]]; then
echo "[ERROR] Run as root"
exit 1
fi

systemctl stop setfop-daemon 2>/dev/null || true

echo "[INFO] Re-downloading files"

cd /tmp
curl -L "$REPO_URL" | tar -xz

cp -r setfop-daemon-main/* "$INSTALL_DIR"

chmod +x "$INSTALL_DIR/bin/setfop-daemon.py"
chmod +x "$INSTALL_DIR/scripts/"*.sh

mkdir -p "$LOG_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$LIB_DIR"

touch "$LOG_DIR/drift.log"
chmod 644 "$LOG_DIR/drift.log"

cp "$INSTALL_DIR/setfop-daemon.service" /etc/systemd/system/
cp "$INSTALL_DIR/setfop-daemon.logrotate" /etc/logrotate.d/setfop-daemon

systemctl daemon-reload
systemctl restart setfop-daemon

echo "[SUCCESS] setfop-daemon repaired"
