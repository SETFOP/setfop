#!/bin/bash

set -e

INSTALL_DIR="/opt/setfop-daemon"
LOG_DIR="/var/log/setfop"
CONFIG_DIR="/etc/setfop"
LIB_DIR="/var/lib/setfop"

echo "[INFO] Uninstalling setfop-daemon..."

if [[ $EUID -ne 0 ]]; then
echo "[ERROR] Run as root"
exit 1
fi

systemctl stop setfop-daemon 2>/dev/null || true
systemctl disable setfop-daemon 2>/dev/null || true

rm -f /etc/systemd/system/setfop-daemon.service
systemctl daemon-reload

rm -f /etc/logrotate.d/setfop-daemon

echo "[INFO] Removing program files"
rm -rf "$INSTALL_DIR"

echo
read -p "Delete logs in $LOG_DIR ? (y/n): " answer

if [[ "$answer" == "y" ]]; then
rm -rf "$LOG_DIR"
echo "[INFO] Logs removed"
else
echo "[INFO] Logs preserved"
fi

echo "[SUCCESS] setfop-daemon removed"
